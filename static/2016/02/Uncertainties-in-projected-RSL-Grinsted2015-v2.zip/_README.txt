
## Uncertainty distributions for 21st sea level rise in Northern European cities.

This data set has the uncertainty distributions for relative sea level rise for cities in Northern Europe as calculated in Grinsted et al. (2015). 

The data set is divided into separate text files for each city. 


Please email ag[at]glaciology[dot]net if you have questions, or additional data requirements.

Citation: Grinsted, Jevrejeva, Riva, Dahl-Jensen (2015).
          Sea level rise projections for Northern Europe under RCP8.5.
          Clim. Res., 64, 1, doi:10.3354/cr01309

webpage: http://www.glaciology.net/Home/PDFs/Announcements/sealevelriseprojectionsfornortherneuropeunderrcp85



